# -*- coding: utf-8 -*-
{
    'name': 'Sale Quotation Order Line Validation',
    'version': "19.0.1.0.0",
    'license': "LGPL-3",
    'depends': [
        "base",
        "sale"
    ],
    'installable': True,
}